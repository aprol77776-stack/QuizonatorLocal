Quizonator Local для Android — исходный проект APK

Это Android Studio project (WebView shell + локальные HTML/CSS/JS assets).
Требования: Android Studio, JDK 17, Android SDK Platform 35.

Сборка APK:
1. Распакуйте архив.
2. Откройте папку QuizonatorLocal-Android в Android Studio.
3. Дождитесь Gradle Sync и установки Android SDK Platform 35, если потребуется.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

В приложении есть локальная библиотека вопросов, импорт TXT/JSON, тренировки,
история и экспорт резервной копии. Данные хранятся в WebView localStorage.

Ограничения:
- Внешние сайты доступны только при наличии интернета, но авторизация и интеграции
  с их внутренними сессиями не реализованы.
- OCR и AI пока не добавлены.
- Не вводите пароли сторонних сервисов в приложение.
