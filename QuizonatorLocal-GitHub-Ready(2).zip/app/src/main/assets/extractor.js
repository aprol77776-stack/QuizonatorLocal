(function () {
  'use strict';
  if (window.__qlWaygroundInstalled) return;
  window.__qlWaygroundInstalled = true;

  var serial = 0, timer = null;
  var MAX_QUESTIONS = 30, MAX_OPTIONS = 8;
  var MARK = 'data-ql-wayground-option';
  var CONTROL_SELECTOR = '[role="radio"],[role="option"],[role="button"],button,label,input[type="radio"],input[type="checkbox"]';

  function clean(v) {
    return String(v || '').replace(/\u00a0/g, ' ')
      .replace(/[\t\r\n]+/g, ' ').replace(/\s{2,}/g, ' ')
      .trim().slice(0, 900);
  }
  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 2 && r.height > 2 && s.display !== 'none' &&
      s.visibility !== 'hidden' && Number(s.opacity) !== 0;
  }
  function label(el) {
    if (!el) return '';
    return clean(el.innerText || el.textContent || el.getAttribute('aria-label'));
  }
  function uniq(a) { return Array.from(new Set(a)); }

  function collectControls() {
    var found = [];
    try {
      document.querySelectorAll(CONTROL_SELECTOR).forEach(function (node) {
        if (!visible(node)) return;
        if (node.matches('input')) node = node.closest('label') || node.parentElement || node;
        // Exclude controls that look like navigation, dialogs, or submit actions.
        var t = label(node);
        if (!t || t.length > 220) return;
        if (/^(next|continue|submit|finish|exit|join|start|back|далее|продолжить|завершить|назад)$/i.test(t)) return;
        found.push(node);
      });
    } catch (_) {}
    found = uniq(found);
    return found.filter(function (node) {
      return !found.some(function (other) {
        return other !== node && other.contains(node) &&
          other.matches('[role="button"],[role="radio"],[role="option"],button,label');
      });
    });
  }

  function buildGroups(controls) {
    var candidates = [];
    controls.forEach(function (node) {
      var p = node.parentElement, depth = 0;
      while (p && p !== document.body && depth++ < 7) {
        var contained = controls.filter(function (c) { return p.contains(c); });
        if (contained.length >= 2 && contained.length <= MAX_OPTIONS) {
          var texts = uniq(contained.map(label).filter(Boolean));
          if (texts.length >= 2) {
            var allText = clean(p.innerText || p.textContent);
            candidates.push({ root: p, nodes: contained, labels: texts, textSize: allText.length });
          }
        }
        p = p.parentElement;
      }
    });
    candidates.sort(function (a, b) {
      return a.textSize - b.textSize || a.nodes.length - b.nodes.length;
    });
    var groups = [];
    candidates.forEach(function (g) {
      var signature = g.labels.join('|');
      var duplicate = groups.some(function (x) {
        return x.signature === signature || x.root.contains(g.root) || g.root.contains(x.root);
      });
      if (!duplicate) groups.push({
        root: g.root, nodes: uniq(g.nodes), labels: g.labels, signature: signature
      });
    });
    return groups.slice(0, MAX_QUESTIONS);
  }

  function questionText(group) {
    var best = '', bestScore = -1;
    var p = group.root;
    for (var depth = 0; p && p !== document.body && depth < 6; depth++, p = p.parentElement) {
      var candidate = clean(p.innerText || p.textContent);
      group.labels.forEach(function (option) {
        if (!option) return;
        candidate = clean(candidate.split(option).join(' '));
      });
      candidate = clean(candidate);
      if (candidate.length < 8 || candidate.length > 520) continue;
      var score = 100 - Math.abs(candidate.length - 100);
      if (/[?？]\s*$/.test(candidate)) score += 35;
      if (candidate.split(' ').length < 3) score -= 20;
      if (score > bestScore) { bestScore = score; best = candidate; }
    }
    return best;
  }

  function scan() {
    var controls = collectControls();
    var groups = buildGroups(controls);
    var output = [];
    groups.forEach(function (group) {
      var question = questionText(group);
      if (!question) return;
      var qid = 'wg-' + (++serial), options = [];
      group.nodes.slice(0, MAX_OPTIONS).forEach(function (node, index) {
        var value = label(node);
        if (!value) return;
        var id = qid + '-o-' + index;
        node.setAttribute(MARK, id);
        options.push({ id: id, text: value });
      });
      if (options.length >= 2)
        output.push({ id: qid, text: question, options: options });
    });
    try {
      if (window.QuizonatorLocal && window.QuizonatorLocal.onQuestions)
        window.QuizonatorLocal.onQuestions(JSON.stringify(output));
    } catch (_) {}
    return output.length;
  }

  window.__qlScan = scan;
  window.__qlMark = function (id) {
    var nodes = document.querySelectorAll('[' + MARK + ']');
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].getAttribute(MARK) === String(id)) {
        nodes[i].style.setProperty('outline', '3px solid #16834a', 'important');
        nodes[i].style.setProperty('background', '#d9f7e5', 'important');
        nodes[i].style.setProperty('border-radius', '10px', 'important');
        return true;
      }
    }
    return false;
  };

  try {
    new MutationObserver(function () {
      if (timer) clearTimeout(timer);
      timer = setTimeout(scan, 500);
    }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (_) {}
  setTimeout(scan, 900);
})();
