package com.quizonator.local;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private TextView status;
    private JSONArray latestQuestions = new JSONArray();
    private JSONArray bank;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        bank = loadBank();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(8), dp(8), dp(8), dp(6));
        address = new EditText(this);
        address.setSingleLine(true);
        address.setText("https://wayground.com/join");
        address.setHint("Адрес страницы");
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        bar.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button go = new Button(this); go.setText("Открыть");
        bar.addView(go, new LinearLayout.LayoutParams(dp(92), dp(48)));
        root.addView(bar);

        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(dp(8), 0, dp(8), dp(4));
        Button analyze = new Button(this); analyze.setText("Распознать");
        Button add = new Button(this); add.setText("Добавить в базу");
        Button manage = new Button(this); manage.setText("База");
        Button back = new Button(this); back.setText("Назад");
        actions.addView(analyze, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(add, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(manage, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(back, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(actions);
        status = new TextView(this); status.setTextColor(Color.rgb(70,70,70));
        status.setPadding(dp(12), dp(5), dp(12), dp(7));
        status.setText("Готово. Открой страницу тренировочного теста и нажми «Распознать».");
        root.addView(status);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PageBridge(), "QuizonatorLocal");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                address.setText(url);
                injectExtractor();
                status.setText("Страница загружена. Нажми «Распознать».");
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        go.setOnClickListener(v -> openAddress());
        address.setOnEditorActionListener((v, action, event) -> { if (action == EditorInfo.IME_ACTION_GO) { openAddress(); return true; } return false; });
        analyze.setOnClickListener(v -> analyzePage());
        add.setOnClickListener(v -> addCurrentQuestion());
        manage.setOnClickListener(v -> showBank());
        back.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        web.loadUrl(address.getText().toString());
    }

    private void openAddress() {
        String url = address.getText().toString().trim();
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        String host = android.net.Uri.parse(url).getHost();
        if (host == null || !(host.equals("wayground.com") || host.endsWith(".wayground.com") ||
                host.equals("quizizz.com") || host.endsWith(".quizizz.com"))) {
            Toast.makeText(this, "Поддерживается только Wayground / Quizizz", Toast.LENGTH_LONG).show();
            return;
        }
        web.loadUrl(url);
    }

    private void injectExtractor() {
        try {
            java.io.InputStream in = getAssets().open("extractor.js");
            byte[] bytes = new byte[in.available()]; in.read(bytes); in.close();
            String js = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
            web.evaluateJavascript(js, null);
        } catch (Exception e) { status.setText("Не удалось запустить распознавание: " + e.getMessage()); }
    }

    private void analyzePage() {
        injectExtractor();
        web.evaluateJavascript("window.__qlScan && window.__qlScan()", null);
        status.setText("Сканирую страницу…");
    }

    private class PageBridge {
        @JavascriptInterface public void onQuestions(String json) {
            runOnUiThread(() -> {
                try {
                    latestQuestions = new JSONArray(json);
                    int found = latestQuestions.length();
                    if (found == 0) { status.setText("Вопросы не распознаны. На этой странице пока нет поддерживаемой структуры."); return; }
                    int matches = 0;
                    for (int i=0;i<found;i++) {
                        JSONObject q = latestQuestions.getJSONObject(i);
                        JSONObject match = findMatch(q);
                        if (match != null) {
                            String answer = match.optString("answer", "");
                            JSONArray opts = q.optJSONArray("options");
                            for (int j=0; opts != null && j<opts.length(); j++) {
                                JSONObject opt = opts.getJSONObject(j);
                                if (similar(opt.optString("text"), answer) >= 0.90) {
                                    String id = opt.optString("id", "");
                                    web.evaluateJavascript("window.__qlMark && window.__qlMark(" + JSONObject.quote(id) + ")", null);
                                    matches++; break;
                                }
                            }
                        }
                    }
                    status.setText("Найдено вопросов: " + found + ". Совпадений с локальной базой: " + matches + ". Подсвечиваются только точные совпадения.");
                } catch (Exception e) { status.setText("Ошибка обработки страницы: " + e.getMessage()); }
            });
        }
    }

    private JSONArray loadBank() {
        try { return new JSONArray(getPreferences(0).getString("bank", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private void saveBank() { getPreferences(0).edit().putString("bank", bank.toString()).apply(); }

    private JSONObject findMatch(JSONObject question) {
        String q = question.optString("text", "");
        JSONObject best = null;
        double bestScore = 0, secondScore = 0;
        for (int i = 0; i < bank.length(); i++) {
            JSONObject item = bank.optJSONObject(i);
            if (item == null) continue;
            double s = similar(q, item.optString("question", ""));
            if (s > bestScore) {
                secondScore = bestScore;
                bestScore = s;
                best = item;
            } else if (s > secondScore) {
                secondScore = s;
            }
        }
        // Refuse close calls: a wrong highlight is worse than no highlight.
        return bestScore >= 0.86 && (bestScore - secondScore) >= 0.10 ? best : null;
    }

    private String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
    }
    private double similar(String a, String b) {
        String x = norm(a), y = norm(b);
        if (x.isEmpty() || y.isEmpty()) return 0;
        if (x.equals(y)) return 1.0;
        String[] aa = x.split(" "), bb = y.split(" ");
        java.util.HashSet<String> sa = new java.util.HashSet<>(), sb = new java.util.HashSet<>();
        java.util.Collections.addAll(sa, aa);
        java.util.Collections.addAll(sb, bb);
        java.util.HashSet<String> intersection = new java.util.HashSet<>(sa);
        intersection.retainAll(sb);
        java.util.HashSet<String> union = new java.util.HashSet<>(sa);
        union.addAll(sb);
        double jaccard = union.isEmpty() ? 0 : (double) intersection.size() / union.size();
        double containment = (double) intersection.size() / Math.max(1, Math.min(sa.size(), sb.size()));
        // Exact phrase containment helps when the page adds a short prefix/suffix.
        if (x.length() > 18 && y.length() > 18 && (x.contains(y) || y.contains(x)))
            return Math.max(0.94, jaccard);
        return Math.max(jaccard, containment * 0.90);
    }

    private void addCurrentQuestion() {
        if (latestQuestions.length() == 0) {
            Toast.makeText(this, "Сначала распознай страницу", Toast.LENGTH_SHORT).show();
            return;
        }
        JSONArray labels = new JSONArray();
        java.util.ArrayList<String> choices = new java.util.ArrayList<>();
        java.util.ArrayList<String> questionLabels = new java.util.ArrayList<>();
        for (int i = 0; i < latestQuestions.length(); i++) {
            JSONObject q = latestQuestions.optJSONObject(i);
            if (q != null) questionLabels.add(q.optString("text", "Вопрос " + (i + 1)));
        }
        new AlertDialog.Builder(this)
            .setTitle("Какой вопрос добавить?")
            .setItems(questionLabels.toArray(new String[0]), (dialog, which) -> {
                JSONObject q = latestQuestions.optJSONObject(which);
                if (q == null) return;
                JSONArray options = q.optJSONArray("options");
                choices.clear();
                for (int j = 0; options != null && j < options.length(); j++) {
                    JSONObject opt = options.optJSONObject(j);
                    if (opt != null) choices.add(opt.optString("text", ""));
                }
                if (choices.size() < 2) {
                    Toast.makeText(this, "Варианты ответа не распознаны", Toast.LENGTH_SHORT).show();
                    return;
                }
                new AlertDialog.Builder(this)
                    .setTitle("Выбери правильный ответ")
                    .setSingleChoiceItems(choices.toArray(new String[0]), -1, (d, selected) -> {
                        String answer = choices.get(selected);
                        try {
                            JSONObject item = new JSONObject();
                            item.put("question", q.optString("text"));
                            item.put("answer", answer);
                            bank.put(item);
                            saveBank();
                            status.setText("Сохранено в локальную базу. Вопросов: " + bank.length());
                        } catch (Exception e) {
                            status.setText("Не удалось сохранить вопрос.");
                        }
                        d.dismiss();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private void showBank() {
        if (bank.length() == 0) {
            new AlertDialog.Builder(this).setTitle("Локальная база")
                .setMessage("Пока нет сохранённых вопросов. Распознай тренировочный вопрос и добавь правильный вариант.")
                .setPositiveButton("Понятно", null).show();
            return;
        }
        java.util.ArrayList<String> rows = new java.util.ArrayList<>();
        for (int i = 0; i < bank.length(); i++) {
            JSONObject item = bank.optJSONObject(i);
            if (item == null) continue;
            String q = item.optString("question", "Вопрос");
            String a = item.optString("answer", "");
            rows.add((i + 1) + ". " + q + "\nОтвет: " + a);
        }
        new AlertDialog.Builder(this)
            .setTitle("Локальная база · " + bank.length())
            .setItems(rows.toArray(new String[0]), (dialog, which) -> {
                new AlertDialog.Builder(this)
                    .setTitle("Удалить запись?")
                    .setMessage(rows.get(which))
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (d, w) -> {
                        JSONArray updated = new JSONArray();
                        for (int i = 0; i < bank.length(); i++) {
                            if (i == which) continue;
                            JSONObject item = bank.optJSONObject(i);
                            if (item != null) updated.put(item);
                        }
                        bank = updated;
                        saveBank();
                        status.setText("Запись удалена. В базе: " + bank.length());
                    }).show();
            })
            .setNegativeButton("Закрыть", null)
            .show();
    }

    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
