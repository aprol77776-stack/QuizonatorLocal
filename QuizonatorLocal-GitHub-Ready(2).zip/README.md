# Quizonator Local — Wayground edition

A focused Android prototype for Wayground / Quizizz practice pages.

## Features in this preview
- Opens only Wayground / Quizizz domains.
- Reads visible question and answer controls from the rendered page.
- Attempts to group visible answer choices with their question.
- Stores a selected correct option in a local on-device bank.
- Highlights an option only when a sufficiently strong, unambiguous local match is found.
- Supports multiple questions detected on the current page.

## Boundaries
- The app reads visible page content only. It does not inspect hidden answer keys, private app state, undocumented endpoints, or bypass platform protections.
- It cannot know the correct answer to a new question offline. The user must add a verified answer to the local bank first.
- This extractor is heuristic and has not yet been validated against all Wayground layouts, question types, or app versions.
- Image questions, audio questions, and drag-and-drop activities are not supported in this preview.

## Build
Use the repository's GitHub Actions workflow to build a debug APK.
